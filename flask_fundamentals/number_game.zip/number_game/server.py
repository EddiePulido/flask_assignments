from flask import Flask, flash, render_template, request, redirect, session
import random

app = Flask(__name__)
app.secret_key = 'ThisIsSecret'



@app.route('/')
def index():
    if 'num' not in session or session['num'] == None:
        session['num'] = random.randint(1,100)
    else:
        pass
    
    return render_template('index.html',test = session['num'])

@app.route('/guess', methods=['POST'])
def checkNumber():
    error = None
    success = None
    guess = request.form['guess']
    if request.method == 'POST':
        if guess.isdigit():
            numguess = int(guess)
            if numguess == session['num']:
                flash('Correct', 'success')
                return redirect('/')
            elif numguess > session['num']:
                flash('Too high', 'error')
            else:
                flash('Too low', 'error')
        else:
            flash('Not a valid guess', 'error')
    elif isinstance(guess, str):
        flash('Not a valid guess', 'error')
    else:
        flash('Not a valid guess', 'error')

    return redirect('/')

@app.route('/reset', methods=['GET', 'POST'])
def reset():
    session['num'] = None
    return redirect('/')

if __name__ == '__main__':
    app.run(debug = True)